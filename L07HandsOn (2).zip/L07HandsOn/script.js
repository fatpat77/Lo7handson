function regexChecker() {             
    let nameRegex = /^[A-Z/d][a-z/d]$/;
    var firstName = "First Name";
    var lastName = "Last Name";
     if (firstName.match(nameRegex) && lastName.match(nameRegex)) {
     alert("Yay! Your inputs were all correct!");
    console.log(true);
  }
    else {
    alert("Oh no! Thats an invalid format!");
    onsole.log(false);
  }
}

        
        
       
       
    
      
   
